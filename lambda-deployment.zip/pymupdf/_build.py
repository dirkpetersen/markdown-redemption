mupdf_location = 'https://mupdf.com/downloads/archive/mupdf-1.26.10-source.tar.gz'
pymupdf_version = '1.26.5'
pymupdf_version_tuple = (1, 26, 5)
pymupdf_git_sha = 'cc13f8081799c42674a15ef7af6ed90d43b95e89'
pymupdf_git_diff = ''
pymupdf_git_branch = 'main'
swig_version = '4.3.1'
swig_version_tuple = (4, 3, 1)
